package com.MAVLink.enums;

public class PARACHUTE_ACTION
{
  public static final int PARACHUTE_ACTION_ENUM_END = 3;
  public static final int PARACHUTE_DISABLE = 0;
  public static final int PARACHUTE_ENABLE = 1;
  public static final int PARACHUTE_RELEASE = 2;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.PARACHUTE_ACTION
 * JD-Core Version:    0.6.2
 */