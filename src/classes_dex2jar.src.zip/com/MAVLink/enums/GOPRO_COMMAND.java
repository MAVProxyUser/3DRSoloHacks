package com.MAVLink.enums;

public class GOPRO_COMMAND
{
  public static final int GOPRO_COMMAND_BATTERY = 3;
  public static final int GOPRO_COMMAND_CAPTURE_MODE = 1;
  public static final int GOPRO_COMMAND_ENUM_END = 255;
  public static final int GOPRO_COMMAND_MODEL = 4;
  public static final int GOPRO_COMMAND_POWER = 0;
  public static final int GOPRO_COMMAND_REQUEST_FAILED = 254;
  public static final int GOPRO_COMMAND_SHUTTER = 2;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.GOPRO_COMMAND
 * JD-Core Version:    0.6.2
 */