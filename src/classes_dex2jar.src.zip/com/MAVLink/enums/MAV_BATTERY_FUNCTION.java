package com.MAVLink.enums;

public class MAV_BATTERY_FUNCTION
{
  public static final int MAV_BATTERY_FUNCTION_ALL = 1;
  public static final int MAV_BATTERY_FUNCTION_AVIONICS = 3;
  public static final int MAV_BATTERY_FUNCTION_ENUM_END = 5;
  public static final int MAV_BATTERY_FUNCTION_PROPULSION = 2;
  public static final int MAV_BATTERY_FUNCTION_UNKNOWN = 0;
  public static final int MAV_BATTERY_TYPE_PAYLOAD = 4;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.MAV_BATTERY_FUNCTION
 * JD-Core Version:    0.6.2
 */