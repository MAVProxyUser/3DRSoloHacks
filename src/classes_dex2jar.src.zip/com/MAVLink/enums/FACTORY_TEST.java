package com.MAVLink.enums;

public class FACTORY_TEST
{
  public static final int FACTORY_TEST_AXIS_RANGE_LIMITS = 0;
  public static final int FACTORY_TEST_ENUM_END = 1;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.FACTORY_TEST
 * JD-Core Version:    0.6.2
 */