package com.MAVLink.enums;

public class GIMBAL_AXIS_CALIBRATION_STATUS
{
  public static final int GIMBAL_AXIS_CALIBRATION_STATUS_ENUM_END = 3;
  public static final int GIMBAL_AXIS_CALIBRATION_STATUS_FAILED = 2;
  public static final int GIMBAL_AXIS_CALIBRATION_STATUS_IN_PROGRESS = 0;
  public static final int GIMBAL_AXIS_CALIBRATION_STATUS_SUCCEEDED = 1;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.GIMBAL_AXIS_CALIBRATION_STATUS
 * JD-Core Version:    0.6.2
 */