package com.MAVLink.enums;

public class GOPRO_HEARTBEAT_STATUS
{
  public static final int GOPRO_HEARTBEAT_STATUS_CONNECTED = 2;
  public static final int GOPRO_HEARTBEAT_STATUS_DISCONNECTED = 0;
  public static final int GOPRO_HEARTBEAT_STATUS_ENUM_END = 4;
  public static final int GOPRO_HEARTBEAT_STATUS_INCOMPATIBLE = 1;
  public static final int GOPRO_HEARTBEAT_STATUS_RECORDING = 3;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.GOPRO_HEARTBEAT_STATUS
 * JD-Core Version:    0.6.2
 */