package com.MAVLink.enums;

public class LIMITS_STATE
{
  public static final int LIMITS_DISABLED = 1;
  public static final int LIMITS_ENABLED = 2;
  public static final int LIMITS_INIT = 0;
  public static final int LIMITS_RECOVERED = 5;
  public static final int LIMITS_RECOVERING = 4;
  public static final int LIMITS_STATE_ENUM_END = 6;
  public static final int LIMITS_TRIGGERED = 3;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.LIMITS_STATE
 * JD-Core Version:    0.6.2
 */