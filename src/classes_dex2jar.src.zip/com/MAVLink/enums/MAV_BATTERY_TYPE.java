package com.MAVLink.enums;

public class MAV_BATTERY_TYPE
{
  public static final int MAV_BATTERY_TYPE_ENUM_END = 5;
  public static final int MAV_BATTERY_TYPE_LIFE = 2;
  public static final int MAV_BATTERY_TYPE_LION = 3;
  public static final int MAV_BATTERY_TYPE_LIPO = 1;
  public static final int MAV_BATTERY_TYPE_NIMH = 4;
  public static final int MAV_BATTERY_TYPE_UNKNOWN;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.MAV_BATTERY_TYPE
 * JD-Core Version:    0.6.2
 */