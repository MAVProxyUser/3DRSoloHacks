package com.MAVLink.enums;

public class MAV_MOUNT_MODE
{
  public static final int MAV_MOUNT_MODE_ENUM_END = 5;
  public static final int MAV_MOUNT_MODE_GPS_POINT = 4;
  public static final int MAV_MOUNT_MODE_MAVLINK_TARGETING = 2;
  public static final int MAV_MOUNT_MODE_NEUTRAL = 1;
  public static final int MAV_MOUNT_MODE_RC_TARGETING = 3;
  public static final int MAV_MOUNT_MODE_RETRACT;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.MAV_MOUNT_MODE
 * JD-Core Version:    0.6.2
 */