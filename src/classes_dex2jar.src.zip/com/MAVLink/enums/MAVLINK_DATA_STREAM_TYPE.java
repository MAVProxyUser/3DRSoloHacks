package com.MAVLink.enums;

public class MAVLINK_DATA_STREAM_TYPE
{
  public static final int MAVLINK_DATA_STREAM_IMG_BMP = 2;
  public static final int MAVLINK_DATA_STREAM_IMG_JPEG = 1;
  public static final int MAVLINK_DATA_STREAM_IMG_PGM = 5;
  public static final int MAVLINK_DATA_STREAM_IMG_PNG = 6;
  public static final int MAVLINK_DATA_STREAM_IMG_RAW32U = 4;
  public static final int MAVLINK_DATA_STREAM_IMG_RAW8U = 3;
  public static final int MAVLINK_DATA_STREAM_TYPE_ENUM_END = 7;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.MAVLINK_DATA_STREAM_TYPE
 * JD-Core Version:    0.6.2
 */