package com.MAVLink.enums;

public class MAV_ESTIMATOR_TYPE
{
  public static final int MAV_ESTIMATOR_TYPE_ENUM_END = 6;
  public static final int MAV_ESTIMATOR_TYPE_GPS = 4;
  public static final int MAV_ESTIMATOR_TYPE_GPS_INS = 5;
  public static final int MAV_ESTIMATOR_TYPE_NAIVE = 1;
  public static final int MAV_ESTIMATOR_TYPE_VIO = 3;
  public static final int MAV_ESTIMATOR_TYPE_VISION = 2;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.MAV_ESTIMATOR_TYPE
 * JD-Core Version:    0.6.2
 */