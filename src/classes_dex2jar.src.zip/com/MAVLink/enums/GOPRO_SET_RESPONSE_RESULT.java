package com.MAVLink.enums;

public class GOPRO_SET_RESPONSE_RESULT
{
  public static final int GOPRO_SET_RESPONSE_RESULT_ENUM_END = 2;
  public static final int GOPRO_SET_RESPONSE_RESULT_FAILURE = 0;
  public static final int GOPRO_SET_RESPONSE_RESULT_SUCCESS = 1;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.GOPRO_SET_RESPONSE_RESULT
 * JD-Core Version:    0.6.2
 */