package com.MAVLink.enums;

public class FENCE_ACTION
{
  public static final int FENCE_ACTION_ENUM_END = 4;
  public static final int FENCE_ACTION_GUIDED = 1;
  public static final int FENCE_ACTION_GUIDED_THR_PASS = 3;
  public static final int FENCE_ACTION_NONE = 0;
  public static final int FENCE_ACTION_REPORT = 2;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.FENCE_ACTION
 * JD-Core Version:    0.6.2
 */