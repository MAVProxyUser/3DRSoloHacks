package com.MAVLink.enums;

public class SERIAL_CONTROL_DEV
{
  public static final int SERIAL_CONTROL_DEV_ENUM_END = 4;
  public static final int SERIAL_CONTROL_DEV_GPS1 = 2;
  public static final int SERIAL_CONTROL_DEV_GPS2 = 3;
  public static final int SERIAL_CONTROL_DEV_TELEM1 = 0;
  public static final int SERIAL_CONTROL_DEV_TELEM2 = 1;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.SERIAL_CONTROL_DEV
 * JD-Core Version:    0.6.2
 */