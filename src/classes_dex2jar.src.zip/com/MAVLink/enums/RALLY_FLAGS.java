package com.MAVLink.enums;

public class RALLY_FLAGS
{
  public static final int FAVORABLE_WIND = 1;
  public static final int LAND_IMMEDIATELY = 2;
  public static final int RALLY_FLAGS_ENUM_END = 3;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.RALLY_FLAGS
 * JD-Core Version:    0.6.2
 */