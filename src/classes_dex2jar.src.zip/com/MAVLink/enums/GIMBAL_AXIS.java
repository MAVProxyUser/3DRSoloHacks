package com.MAVLink.enums;

public class GIMBAL_AXIS
{
  public static final int GIMBAL_AXIS_ENUM_END = 3;
  public static final int GIMBAL_AXIS_PITCH = 1;
  public static final int GIMBAL_AXIS_ROLL = 2;
  public static final int GIMBAL_AXIS_YAW;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.GIMBAL_AXIS
 * JD-Core Version:    0.6.2
 */