package com.MAVLink.enums;

public class FENCE_BREACH
{
  public static final int FENCE_BREACH_BOUNDARY = 3;
  public static final int FENCE_BREACH_ENUM_END = 4;
  public static final int FENCE_BREACH_MAXALT = 2;
  public static final int FENCE_BREACH_MINALT = 1;
  public static final int FENCE_BREACH_NONE;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.FENCE_BREACH
 * JD-Core Version:    0.6.2
 */