package com.MAVLink.enums;

public class MAV_DISTANCE_SENSOR
{
  public static final int MAV_DISTANCE_SENSOR_ENUM_END = 2;
  public static final int MAV_DISTANCE_SENSOR_LASER = 0;
  public static final int MAV_DISTANCE_SENSOR_ULTRASOUND = 1;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.MAV_DISTANCE_SENSOR
 * JD-Core Version:    0.6.2
 */