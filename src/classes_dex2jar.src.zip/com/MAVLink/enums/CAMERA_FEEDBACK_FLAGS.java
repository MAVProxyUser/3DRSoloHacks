package com.MAVLink.enums;

public class CAMERA_FEEDBACK_FLAGS
{
  public static final int BADEXPOSURE = 2;
  public static final int CAMERA_FEEDBACK_FLAGS_ENUM_END = 5;
  public static final int CLOSEDLOOP = 3;
  public static final int OPENLOOP = 4;
  public static final int VIDEO = 1;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.CAMERA_FEEDBACK_FLAGS
 * JD-Core Version:    0.6.2
 */