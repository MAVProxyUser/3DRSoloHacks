package com.MAVLink.enums;

public class LIMIT_MODULE
{
  public static final int LIMIT_ALTITUDE = 4;
  public static final int LIMIT_GEOFENCE = 2;
  public static final int LIMIT_GPSLOCK = 1;
  public static final int LIMIT_MODULE_ENUM_END = 5;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.LIMIT_MODULE
 * JD-Core Version:    0.6.2
 */