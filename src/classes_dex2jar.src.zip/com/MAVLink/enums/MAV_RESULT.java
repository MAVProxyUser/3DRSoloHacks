package com.MAVLink.enums;

public class MAV_RESULT
{
  public static final int MAV_RESULT_ACCEPTED = 0;
  public static final int MAV_RESULT_DENIED = 2;
  public static final int MAV_RESULT_ENUM_END = 5;
  public static final int MAV_RESULT_FAILED = 4;
  public static final int MAV_RESULT_TEMPORARILY_REJECTED = 1;
  public static final int MAV_RESULT_UNSUPPORTED = 3;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.MAV_RESULT
 * JD-Core Version:    0.6.2
 */