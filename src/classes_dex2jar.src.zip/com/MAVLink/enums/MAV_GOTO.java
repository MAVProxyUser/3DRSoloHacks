package com.MAVLink.enums;

public class MAV_GOTO
{
  public static final int MAV_GOTO_DO_CONTINUE = 1;
  public static final int MAV_GOTO_DO_HOLD = 0;
  public static final int MAV_GOTO_ENUM_END = 4;
  public static final int MAV_GOTO_HOLD_AT_CURRENT_POSITION = 2;
  public static final int MAV_GOTO_HOLD_AT_SPECIFIED_POSITION = 3;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.MAV_GOTO
 * JD-Core Version:    0.6.2
 */