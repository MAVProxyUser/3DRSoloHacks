package com.MAVLink.enums;

public class GIMBAL_AXIS_CALIBRATION_REQUIRED
{
  public static final int GIMBAL_AXIS_CALIBRATION_REQUIRED_ENUM_END = 3;
  public static final int GIMBAL_AXIS_CALIBRATION_REQUIRED_FALSE = 2;
  public static final int GIMBAL_AXIS_CALIBRATION_REQUIRED_TRUE = 1;
  public static final int GIMBAL_AXIS_CALIBRATION_REQUIRED_UNKNOWN;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.GIMBAL_AXIS_CALIBRATION_REQUIRED
 * JD-Core Version:    0.6.2
 */