package com.MAVLink.enums;

public class MOTOR_TEST_THROTTLE_TYPE
{
  public static final int MOTOR_TEST_THROTTLE_PERCENT = 0;
  public static final int MOTOR_TEST_THROTTLE_PILOT = 2;
  public static final int MOTOR_TEST_THROTTLE_PWM = 1;
  public static final int MOTOR_TEST_THROTTLE_TYPE_ENUM_END = 3;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.MOTOR_TEST_THROTTLE_TYPE
 * JD-Core Version:    0.6.2
 */