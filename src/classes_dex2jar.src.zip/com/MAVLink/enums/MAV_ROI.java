package com.MAVLink.enums;

public class MAV_ROI
{
  public static final int MAV_ROI_ENUM_END = 5;
  public static final int MAV_ROI_LOCATION = 3;
  public static final int MAV_ROI_NONE = 0;
  public static final int MAV_ROI_TARGET = 4;
  public static final int MAV_ROI_WPINDEX = 2;
  public static final int MAV_ROI_WPNEXT = 1;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.MAV_ROI
 * JD-Core Version:    0.6.2
 */