package com.MAVLink.enums;

public class MAG_CAL_STATUS
{
  public static final int MAG_CAL_FAILED = 5;
  public static final int MAG_CAL_NOT_STARTED = 0;
  public static final int MAG_CAL_RUNNING_STEP_ONE = 2;
  public static final int MAG_CAL_RUNNING_STEP_TWO = 3;
  public static final int MAG_CAL_STATUS_ENUM_END = 6;
  public static final int MAG_CAL_SUCCESS = 4;
  public static final int MAG_CAL_WAITING_TO_START = 1;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.MAG_CAL_STATUS
 * JD-Core Version:    0.6.2
 */