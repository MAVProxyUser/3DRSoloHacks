package com.MAVLink.enums;

public class GRIPPER_ACTIONS
{
  public static final int GRIPPER_ACTIONS_ENUM_END = 2;
  public static final int GRIPPER_ACTION_GRAB = 1;
  public static final int GRIPPER_ACTION_RELEASE;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.GRIPPER_ACTIONS
 * JD-Core Version:    0.6.2
 */