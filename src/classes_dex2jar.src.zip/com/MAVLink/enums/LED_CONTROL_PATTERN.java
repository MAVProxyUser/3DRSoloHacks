package com.MAVLink.enums;

public class LED_CONTROL_PATTERN
{
  public static final int LED_CONTROL_PATTERN_CUSTOM = 255;
  public static final int LED_CONTROL_PATTERN_ENUM_END = 256;
  public static final int LED_CONTROL_PATTERN_FIRMWAREUPDATE = 1;
  public static final int LED_CONTROL_PATTERN_OFF;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.MAVLink.enums.LED_CONTROL_PATTERN
 * JD-Core Version:    0.6.2
 */