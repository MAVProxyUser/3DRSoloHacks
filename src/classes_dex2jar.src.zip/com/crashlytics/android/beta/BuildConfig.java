package com.crashlytics.android.beta;

public final class BuildConfig
{
  public static final String APPLICATION_ID = "com.crashlytics.android.beta";
  public static final String ARTIFACT_ID = "beta";
  public static final String BUILD_NUMBER = "32";
  public static final String BUILD_TYPE = "release";
  public static final boolean DEBUG = false;
  public static final String FLAVOR = "";
  public static final String GROUP = "com.crashlytics.sdk.android";
  public static final int VERSION_CODE = 1;
  public static final String VERSION_NAME = "1.1.1";
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     com.crashlytics.android.beta.BuildConfig
 * JD-Core Version:    0.6.2
 */