package android.support.v7.internal.app;

class ToolbarActionBar$1
  implements Runnable
{
  ToolbarActionBar$1(ToolbarActionBar paramToolbarActionBar)
  {
  }

  public void run()
  {
    this.this$0.populateOptionsMenu();
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.internal.app.ToolbarActionBar.1
 * JD-Core Version:    0.6.2
 */