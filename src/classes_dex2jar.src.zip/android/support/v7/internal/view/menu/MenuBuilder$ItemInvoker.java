package android.support.v7.internal.view.menu;

public abstract interface MenuBuilder$ItemInvoker
{
  public abstract boolean invokeItem(MenuItemImpl paramMenuItemImpl);
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.internal.view.menu.MenuBuilder.ItemInvoker
 * JD-Core Version:    0.6.2
 */