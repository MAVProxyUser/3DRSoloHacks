package android.support.v7.internal.view.menu;

import android.support.v7.widget.ListPopupWindow;

public abstract class ActionMenuItemView$PopupCallback
{
  public abstract ListPopupWindow getPopup();
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.internal.view.menu.ActionMenuItemView.PopupCallback
 * JD-Core Version:    0.6.2
 */