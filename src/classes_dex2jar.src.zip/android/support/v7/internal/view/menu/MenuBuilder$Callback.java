package android.support.v7.internal.view.menu;

import android.view.MenuItem;

public abstract interface MenuBuilder$Callback
{
  public abstract boolean onMenuItemSelected(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem);

  public abstract void onMenuModeChange(MenuBuilder paramMenuBuilder);
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.internal.view.menu.MenuBuilder.Callback
 * JD-Core Version:    0.6.2
 */