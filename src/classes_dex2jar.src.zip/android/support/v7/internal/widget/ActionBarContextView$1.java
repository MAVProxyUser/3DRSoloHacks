package android.support.v7.internal.widget;

import android.support.v7.view.ActionMode;
import android.view.View;
import android.view.View.OnClickListener;

class ActionBarContextView$1
  implements View.OnClickListener
{
  ActionBarContextView$1(ActionBarContextView paramActionBarContextView, ActionMode paramActionMode)
  {
  }

  public void onClick(View paramView)
  {
    this.val$mode.finish();
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.internal.widget.ActionBarContextView.1
 * JD-Core Version:    0.6.2
 */