package android.support.v7.internal.widget;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class SpinnerCompat$SavedState$1
  implements Parcelable.Creator<SpinnerCompat.SavedState>
{
  public SpinnerCompat.SavedState createFromParcel(Parcel paramParcel)
  {
    return new SpinnerCompat.SavedState(paramParcel, null);
  }

  public SpinnerCompat.SavedState[] newArray(int paramInt)
  {
    return new SpinnerCompat.SavedState[paramInt];
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.internal.widget.SpinnerCompat.SavedState.1
 * JD-Core Version:    0.6.2
 */