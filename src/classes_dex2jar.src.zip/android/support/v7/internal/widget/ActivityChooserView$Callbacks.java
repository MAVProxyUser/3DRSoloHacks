package android.support.v7.internal.widget;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.support.v4.view.ActionProvider;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.PopupWindow.OnDismissListener;

class ActivityChooserView$Callbacks
  implements AdapterView.OnItemClickListener, View.OnClickListener, View.OnLongClickListener, PopupWindow.OnDismissListener
{
  private ActivityChooserView$Callbacks(ActivityChooserView paramActivityChooserView)
  {
  }

  private void notifyOnDismissListener()
  {
    if (ActivityChooserView.access$1000(this.this$0) != null)
      ActivityChooserView.access$1000(this.this$0).onDismiss();
  }

  public void onClick(View paramView)
  {
    if (paramView == ActivityChooserView.access$700(this.this$0))
    {
      this.this$0.dismissPopup();
      ResolveInfo localResolveInfo = ActivityChooserView.access$000(this.this$0).getDefaultActivity();
      int i = ActivityChooserView.access$000(this.this$0).getDataModel().getActivityIndex(localResolveInfo);
      Intent localIntent = ActivityChooserView.access$000(this.this$0).getDataModel().chooseActivity(i);
      if (localIntent != null)
      {
        localIntent.addFlags(524288);
        this.this$0.getContext().startActivity(localIntent);
      }
      return;
    }
    if (paramView == ActivityChooserView.access$800(this.this$0))
    {
      ActivityChooserView.access$602(this.this$0, false);
      ActivityChooserView.access$500(this.this$0, ActivityChooserView.access$900(this.this$0));
      return;
    }
    throw new IllegalArgumentException();
  }

  public void onDismiss()
  {
    notifyOnDismissListener();
    if (this.this$0.mProvider != null)
      this.this$0.mProvider.subUiVisibilityChanged(false);
  }

  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    switch (((ActivityChooserView.ActivityChooserViewAdapter)paramAdapterView.getAdapter()).getItemViewType(paramInt))
    {
    default:
      throw new IllegalArgumentException();
    case 1:
      ActivityChooserView.access$500(this.this$0, 2147483647);
    case 0:
    }
    do
    {
      return;
      this.this$0.dismissPopup();
      if (!ActivityChooserView.access$600(this.this$0))
        break;
    }
    while (paramInt <= 0);
    ActivityChooserView.access$000(this.this$0).getDataModel().setDefaultActivity(paramInt);
    return;
    if (ActivityChooserView.access$000(this.this$0).getShowDefaultActivity());
    while (true)
    {
      Intent localIntent = ActivityChooserView.access$000(this.this$0).getDataModel().chooseActivity(paramInt);
      if (localIntent == null)
        break;
      localIntent.addFlags(524288);
      this.this$0.getContext().startActivity(localIntent);
      return;
      paramInt++;
    }
  }

  public boolean onLongClick(View paramView)
  {
    if (paramView == ActivityChooserView.access$700(this.this$0))
    {
      if (ActivityChooserView.access$000(this.this$0).getCount() > 0)
      {
        ActivityChooserView.access$602(this.this$0, true);
        ActivityChooserView.access$500(this.this$0, ActivityChooserView.access$900(this.this$0));
      }
      return true;
    }
    throw new IllegalArgumentException();
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.internal.widget.ActivityChooserView.Callbacks
 * JD-Core Version:    0.6.2
 */