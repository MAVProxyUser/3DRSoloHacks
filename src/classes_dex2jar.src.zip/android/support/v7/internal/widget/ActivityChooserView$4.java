package android.support.v7.internal.widget;

import android.database.DataSetObserver;

class ActivityChooserView$4 extends DataSetObserver
{
  ActivityChooserView$4(ActivityChooserView paramActivityChooserView)
  {
  }

  public void onChanged()
  {
    super.onChanged();
    ActivityChooserView.access$400(this.this$0);
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.internal.widget.ActivityChooserView.4
 * JD-Core Version:    0.6.2
 */