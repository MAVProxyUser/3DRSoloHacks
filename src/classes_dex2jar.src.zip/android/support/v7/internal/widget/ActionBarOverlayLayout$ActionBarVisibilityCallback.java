package android.support.v7.internal.widget;

public abstract interface ActionBarOverlayLayout$ActionBarVisibilityCallback
{
  public abstract void enableContentAnimations(boolean paramBoolean);

  public abstract void hideForSystem();

  public abstract void onContentScrollStarted();

  public abstract void onContentScrollStopped();

  public abstract void onWindowVisibilityChanged(int paramInt);

  public abstract void showForSystem();
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.internal.widget.ActionBarOverlayLayout.ActionBarVisibilityCallback
 * JD-Core Version:    0.6.2
 */