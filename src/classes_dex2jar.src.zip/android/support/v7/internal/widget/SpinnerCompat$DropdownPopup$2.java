package android.support.v7.internal.widget;

import android.view.ViewTreeObserver.OnGlobalLayoutListener;

class SpinnerCompat$DropdownPopup$2
  implements ViewTreeObserver.OnGlobalLayoutListener
{
  SpinnerCompat$DropdownPopup$2(SpinnerCompat.DropdownPopup paramDropdownPopup)
  {
  }

  public void onGlobalLayout()
  {
    this.this$1.computeContentWidth();
    SpinnerCompat.DropdownPopup.access$501(this.this$1);
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.internal.widget.SpinnerCompat.DropdownPopup.2
 * JD-Core Version:    0.6.2
 */