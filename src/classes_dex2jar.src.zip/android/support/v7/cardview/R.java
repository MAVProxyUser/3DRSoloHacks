package android.support.v7.cardview;

public final class R
{
  public static final class attr
  {
    public static final int cardBackgroundColor = 2130772023;
    public static final int cardCornerRadius = 2130772024;
    public static final int cardElevation = 2130772025;
    public static final int cardMaxElevation = 2130772026;
    public static final int cardPreventCornerOverlap = 2130772028;
    public static final int cardUseCompatPadding = 2130772027;
    public static final int contentPadding = 2130772029;
    public static final int contentPaddingBottom = 2130772033;
    public static final int contentPaddingLeft = 2130772030;
    public static final int contentPaddingRight = 2130772031;
    public static final int contentPaddingTop = 2130772032;
  }

  public static final class color
  {
    public static final int cardview_dark_background = 2131427347;
    public static final int cardview_light_background = 2131427348;
    public static final int cardview_shadow_end_color = 2131427349;
    public static final int cardview_shadow_start_color = 2131427350;
  }

  public static final class dimen
  {
    public static final int cardview_compat_inset_shadow = 2131165267;
    public static final int cardview_default_elevation = 2131165268;
    public static final int cardview_default_radius = 2131165269;
  }

  public static final class style
  {
    public static final int CardView = 2131230892;
    public static final int CardView_Dark = 2131230893;
    public static final int CardView_Light = 2131230894;
  }

  public static final class styleable
  {
    public static final int[] CardView = { 2130772023, 2130772024, 2130772025, 2130772026, 2130772027, 2130772028, 2130772029, 2130772030, 2130772031, 2130772032, 2130772033 };
    public static final int CardView_cardBackgroundColor = 0;
    public static final int CardView_cardCornerRadius = 1;
    public static final int CardView_cardElevation = 2;
    public static final int CardView_cardMaxElevation = 3;
    public static final int CardView_cardPreventCornerOverlap = 5;
    public static final int CardView_cardUseCompatPadding = 4;
    public static final int CardView_contentPadding = 6;
    public static final int CardView_contentPaddingBottom = 10;
    public static final int CardView_contentPaddingLeft = 7;
    public static final int CardView_contentPaddingRight = 8;
    public static final int CardView_contentPaddingTop = 9;
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.cardview.R
 * JD-Core Version:    0.6.2
 */