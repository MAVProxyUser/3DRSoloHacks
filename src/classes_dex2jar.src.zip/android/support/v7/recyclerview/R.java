package android.support.v7.recyclerview;

public final class R
{
  public static final class attr
  {
    public static final int layoutManager = 2130772124;
    public static final int reverseLayout = 2130772126;
    public static final int spanCount = 2130772125;
    public static final int stackFromEnd = 2130772127;
  }

  public static final class dimen
  {
    public static final int item_touch_helper_max_drag_scroll_per_frame = 2131165302;
  }

  public static final class id
  {
    public static final int item_touch_helper_previous_elevation = 2131492871;
  }

  public static final class styleable
  {
    public static final int[] RecyclerView = { 16842948, 2130772124, 2130772125, 2130772126, 2130772127 };
    public static final int RecyclerView_android_orientation = 0;
    public static final int RecyclerView_layoutManager = 1;
    public static final int RecyclerView_reverseLayout = 3;
    public static final int RecyclerView_spanCount = 2;
    public static final int RecyclerView_stackFromEnd = 4;
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.recyclerview.R
 * JD-Core Version:    0.6.2
 */