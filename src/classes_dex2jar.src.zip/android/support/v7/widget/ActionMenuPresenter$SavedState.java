package android.support.v7.widget;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

class ActionMenuPresenter$SavedState
  implements Parcelable
{
  public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator()
  {
    public ActionMenuPresenter.SavedState createFromParcel(Parcel paramAnonymousParcel)
    {
      return new ActionMenuPresenter.SavedState(paramAnonymousParcel);
    }

    public ActionMenuPresenter.SavedState[] newArray(int paramAnonymousInt)
    {
      return new ActionMenuPresenter.SavedState[paramAnonymousInt];
    }
  };
  public int openSubMenuId;

  ActionMenuPresenter$SavedState()
  {
  }

  ActionMenuPresenter$SavedState(Parcel paramParcel)
  {
    this.openSubMenuId = paramParcel.readInt();
  }

  public int describeContents()
  {
    return 0;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeInt(this.openSubMenuId);
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.widget.ActionMenuPresenter.SavedState
 * JD-Core Version:    0.6.2
 */