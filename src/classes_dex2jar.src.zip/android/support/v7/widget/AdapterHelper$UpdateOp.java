package android.support.v7.widget;

class AdapterHelper$UpdateOp
{
  static final int ADD = 0;
  static final int MOVE = 3;
  static final int POOL_SIZE = 30;
  static final int REMOVE = 1;
  static final int UPDATE = 2;
  int cmd;
  int itemCount;
  int positionStart;

  AdapterHelper$UpdateOp(int paramInt1, int paramInt2, int paramInt3)
  {
    this.cmd = paramInt1;
    this.positionStart = paramInt2;
    this.itemCount = paramInt3;
  }

  String cmdToString()
  {
    switch (this.cmd)
    {
    default:
      return "??";
    case 0:
      return "add";
    case 1:
      return "rm";
    case 2:
      return "up";
    case 3:
    }
    return "mv";
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject);
    UpdateOp localUpdateOp;
    do
    {
      do
      {
        return true;
        if ((paramObject == null) || (getClass() != paramObject.getClass()))
          return false;
        localUpdateOp = (UpdateOp)paramObject;
        if (this.cmd != localUpdateOp.cmd)
          return false;
      }
      while ((this.cmd == 3) && (Math.abs(this.itemCount - this.positionStart) == 1) && (this.itemCount == localUpdateOp.positionStart) && (this.positionStart == localUpdateOp.itemCount));
      if (this.itemCount != localUpdateOp.itemCount)
        return false;
    }
    while (this.positionStart == localUpdateOp.positionStart);
    return false;
  }

  public int hashCode()
  {
    return 31 * (31 * this.cmd + this.positionStart) + this.itemCount;
  }

  public String toString()
  {
    return "[" + cmdToString() + ",s:" + this.positionStart + "c:" + this.itemCount + "]";
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.widget.AdapterHelper.UpdateOp
 * JD-Core Version:    0.6.2
 */