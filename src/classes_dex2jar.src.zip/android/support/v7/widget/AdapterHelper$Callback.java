package android.support.v7.widget;

abstract interface AdapterHelper$Callback
{
  public abstract RecyclerView.ViewHolder findViewHolder(int paramInt);

  public abstract void markViewHoldersUpdated(int paramInt1, int paramInt2);

  public abstract void offsetPositionsForAdd(int paramInt1, int paramInt2);

  public abstract void offsetPositionsForMove(int paramInt1, int paramInt2);

  public abstract void offsetPositionsForRemovingInvisible(int paramInt1, int paramInt2);

  public abstract void offsetPositionsForRemovingLaidOutOrNewView(int paramInt1, int paramInt2);

  public abstract void onDispatchFirstPass(AdapterHelper.UpdateOp paramUpdateOp);

  public abstract void onDispatchSecondPass(AdapterHelper.UpdateOp paramUpdateOp);
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.widget.AdapterHelper.Callback
 * JD-Core Version:    0.6.2
 */