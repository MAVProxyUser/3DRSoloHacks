package android.support.v7.widget;

import android.view.MenuItem;

public abstract interface ActionMenuView$OnMenuItemClickListener
{
  public abstract boolean onMenuItemClick(MenuItem paramMenuItem);
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.widget.ActionMenuView.OnMenuItemClickListener
 * JD-Core Version:    0.6.2
 */