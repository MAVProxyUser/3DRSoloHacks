package android.support.v7.widget;

class DefaultItemAnimator$MoveInfo
{
  public int fromX;
  public int fromY;
  public RecyclerView.ViewHolder holder;
  public int toX;
  public int toY;

  private DefaultItemAnimator$MoveInfo(RecyclerView.ViewHolder paramViewHolder, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.holder = paramViewHolder;
    this.fromX = paramInt1;
    this.fromY = paramInt2;
    this.toX = paramInt3;
    this.toY = paramInt4;
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.widget.DefaultItemAnimator.MoveInfo
 * JD-Core Version:    0.6.2
 */