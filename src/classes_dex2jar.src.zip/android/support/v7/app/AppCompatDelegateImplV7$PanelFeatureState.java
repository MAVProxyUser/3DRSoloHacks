package android.support.v7.app;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v7.appcompat.R.attr;
import android.support.v7.appcompat.R.layout;
import android.support.v7.appcompat.R.style;
import android.support.v7.appcompat.R.styleable;
import android.support.v7.internal.view.ContextThemeWrapper;
import android.support.v7.internal.view.menu.ListMenuPresenter;
import android.support.v7.internal.view.menu.MenuBuilder;
import android.support.v7.internal.view.menu.MenuPresenter.Callback;
import android.support.v7.internal.view.menu.MenuView;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;

final class AppCompatDelegateImplV7$PanelFeatureState
{
  int background;
  View createdPanelView;
  ViewGroup decorView;
  int featureId;
  Bundle frozenActionViewState;
  Bundle frozenMenuState;
  int gravity;
  boolean isHandled;
  boolean isOpen;
  boolean isPrepared;
  ListMenuPresenter listMenuPresenter;
  Context listPresenterContext;
  MenuBuilder menu;
  public boolean qwertyMode;
  boolean refreshDecorView;
  boolean refreshMenuContent;
  View shownPanelView;
  boolean wasLastOpen;
  int windowAnimations;
  int x;
  int y;

  AppCompatDelegateImplV7$PanelFeatureState(int paramInt)
  {
    this.featureId = paramInt;
    this.refreshDecorView = false;
  }

  void applyFrozenState()
  {
    if ((this.menu != null) && (this.frozenMenuState != null))
    {
      this.menu.restorePresenterStates(this.frozenMenuState);
      this.frozenMenuState = null;
    }
  }

  public void clearMenuPresenters()
  {
    if (this.menu != null)
      this.menu.removeMenuPresenter(this.listMenuPresenter);
    this.listMenuPresenter = null;
  }

  MenuView getListMenuView(MenuPresenter.Callback paramCallback)
  {
    if (this.menu == null)
      return null;
    if (this.listMenuPresenter == null)
    {
      this.listMenuPresenter = new ListMenuPresenter(this.listPresenterContext, R.layout.abc_list_menu_item_layout);
      this.listMenuPresenter.setCallback(paramCallback);
      this.menu.addMenuPresenter(this.listMenuPresenter);
    }
    return this.listMenuPresenter.getMenuView(this.decorView);
  }

  public boolean hasPanelItems()
  {
    boolean bool = true;
    if (this.shownPanelView == null)
      bool = false;
    while ((this.createdPanelView != null) || (this.listMenuPresenter.getAdapter().getCount() > 0))
      return bool;
    return false;
  }

  void onRestoreInstanceState(Parcelable paramParcelable)
  {
    SavedState localSavedState = (SavedState)paramParcelable;
    this.featureId = localSavedState.featureId;
    this.wasLastOpen = localSavedState.isOpen;
    this.frozenMenuState = localSavedState.menuState;
    this.shownPanelView = null;
    this.decorView = null;
  }

  Parcelable onSaveInstanceState()
  {
    SavedState localSavedState = new SavedState(null);
    localSavedState.featureId = this.featureId;
    localSavedState.isOpen = this.isOpen;
    if (this.menu != null)
    {
      localSavedState.menuState = new Bundle();
      this.menu.savePresenterStates(localSavedState.menuState);
    }
    return localSavedState;
  }

  void setMenu(MenuBuilder paramMenuBuilder)
  {
    if (paramMenuBuilder == this.menu);
    do
    {
      return;
      if (this.menu != null)
        this.menu.removeMenuPresenter(this.listMenuPresenter);
      this.menu = paramMenuBuilder;
    }
    while ((paramMenuBuilder == null) || (this.listMenuPresenter == null));
    paramMenuBuilder.addMenuPresenter(this.listMenuPresenter);
  }

  void setStyle(Context paramContext)
  {
    TypedValue localTypedValue = new TypedValue();
    Resources.Theme localTheme = paramContext.getResources().newTheme();
    localTheme.setTo(paramContext.getTheme());
    localTheme.resolveAttribute(R.attr.actionBarPopupTheme, localTypedValue, true);
    if (localTypedValue.resourceId != 0)
      localTheme.applyStyle(localTypedValue.resourceId, true);
    localTheme.resolveAttribute(R.attr.panelMenuListTheme, localTypedValue, true);
    if (localTypedValue.resourceId != 0)
      localTheme.applyStyle(localTypedValue.resourceId, true);
    while (true)
    {
      ContextThemeWrapper localContextThemeWrapper = new ContextThemeWrapper(paramContext, 0);
      localContextThemeWrapper.getTheme().setTo(localTheme);
      this.listPresenterContext = localContextThemeWrapper;
      TypedArray localTypedArray = localContextThemeWrapper.obtainStyledAttributes(R.styleable.Theme);
      this.background = localTypedArray.getResourceId(R.styleable.Theme_panelBackground, 0);
      this.windowAnimations = localTypedArray.getResourceId(R.styleable.Theme_android_windowAnimationStyle, 0);
      localTypedArray.recycle();
      return;
      localTheme.applyStyle(R.style.Theme_AppCompat_CompactMenu, true);
    }
  }

  private static class SavedState
    implements Parcelable
  {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator()
    {
      public AppCompatDelegateImplV7.PanelFeatureState.SavedState createFromParcel(Parcel paramAnonymousParcel)
      {
        return AppCompatDelegateImplV7.PanelFeatureState.SavedState.readFromParcel(paramAnonymousParcel);
      }

      public AppCompatDelegateImplV7.PanelFeatureState.SavedState[] newArray(int paramAnonymousInt)
      {
        return new AppCompatDelegateImplV7.PanelFeatureState.SavedState[paramAnonymousInt];
      }
    };
    int featureId;
    boolean isOpen;
    Bundle menuState;

    private static SavedState readFromParcel(Parcel paramParcel)
    {
      int i = 1;
      SavedState localSavedState = new SavedState();
      localSavedState.featureId = paramParcel.readInt();
      if (paramParcel.readInt() == i);
      while (true)
      {
        localSavedState.isOpen = i;
        if (localSavedState.isOpen)
          localSavedState.menuState = paramParcel.readBundle();
        return localSavedState;
        i = 0;
      }
    }

    public int describeContents()
    {
      return 0;
    }

    public void writeToParcel(Parcel paramParcel, int paramInt)
    {
      paramParcel.writeInt(this.featureId);
      if (this.isOpen);
      for (int i = 1; ; i = 0)
      {
        paramParcel.writeInt(i);
        if (this.isOpen)
          paramParcel.writeBundle(this.menuState);
        return;
      }
    }
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.app.AppCompatDelegateImplV7.PanelFeatureState
 * JD-Core Version:    0.6.2
 */