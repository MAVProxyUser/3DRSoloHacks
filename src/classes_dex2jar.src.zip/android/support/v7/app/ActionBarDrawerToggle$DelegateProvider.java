package android.support.v7.app;

import android.support.annotation.Nullable;

public abstract interface ActionBarDrawerToggle$DelegateProvider
{
  @Nullable
  public abstract ActionBarDrawerToggle.Delegate getDrawerToggleDelegate();
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.app.ActionBarDrawerToggle.DelegateProvider
 * JD-Core Version:    0.6.2
 */