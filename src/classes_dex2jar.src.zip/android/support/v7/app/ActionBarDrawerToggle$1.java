package android.support.v7.app;

import android.view.View;
import android.view.View.OnClickListener;

class ActionBarDrawerToggle$1
  implements View.OnClickListener
{
  ActionBarDrawerToggle$1(ActionBarDrawerToggle paramActionBarDrawerToggle)
  {
  }

  public void onClick(View paramView)
  {
    if (ActionBarDrawerToggle.access$000(this.this$0))
      ActionBarDrawerToggle.access$100(this.this$0);
    while (ActionBarDrawerToggle.access$200(this.this$0) == null)
      return;
    ActionBarDrawerToggle.access$200(this.this$0).onClick(paramView);
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.app.ActionBarDrawerToggle.1
 * JD-Core Version:    0.6.2
 */