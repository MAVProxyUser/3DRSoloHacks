package android.support.v7.gridlayout;

public final class R
{
  public static final class attr
  {
    public static final int alignmentMode = 2130772082;
    public static final int columnCount = 2130772080;
    public static final int columnOrderPreserved = 2130772084;
    public static final int layout_column = 2130772088;
    public static final int layout_columnSpan = 2130772089;
    public static final int layout_columnWeight = 2130772090;
    public static final int layout_gravity = 2130772091;
    public static final int layout_row = 2130772085;
    public static final int layout_rowSpan = 2130772086;
    public static final int layout_rowWeight = 2130772087;
    public static final int orientation = 2130772078;
    public static final int rowCount = 2130772079;
    public static final int rowOrderPreserved = 2130772083;
    public static final int useDefaultMargins = 2130772081;
  }

  public static final class dimen
  {
    public static final int default_gap = 2131165273;
  }

  public static final class id
  {
    public static final int alignBounds = 2131492892;
    public static final int alignMargins = 2131492893;
    public static final int bottom = 2131492894;
    public static final int center = 2131492895;
    public static final int center_horizontal = 2131492896;
    public static final int center_vertical = 2131492897;
    public static final int clip_horizontal = 2131492898;
    public static final int clip_vertical = 2131492899;
    public static final int end = 2131492900;
    public static final int fill = 2131492901;
    public static final int fill_horizontal = 2131492902;
    public static final int fill_vertical = 2131492903;
    public static final int horizontal = 2131492890;
    public static final int left = 2131492887;
    public static final int right = 2131492888;
    public static final int start = 2131492904;
    public static final int top = 2131492905;
    public static final int vertical = 2131492891;
  }

  public static final class styleable
  {
    public static final int[] GridLayout = { 2130772078, 2130772079, 2130772080, 2130772081, 2130772082, 2130772083, 2130772084 };
    public static final int[] GridLayout_Layout = { 16842996, 16842997, 16842998, 16842999, 16843000, 16843001, 16843002, 2130772085, 2130772086, 2130772087, 2130772088, 2130772089, 2130772090, 2130772091 };
    public static final int GridLayout_Layout_android_layout_height = 1;
    public static final int GridLayout_Layout_android_layout_margin = 2;
    public static final int GridLayout_Layout_android_layout_marginBottom = 6;
    public static final int GridLayout_Layout_android_layout_marginLeft = 3;
    public static final int GridLayout_Layout_android_layout_marginRight = 5;
    public static final int GridLayout_Layout_android_layout_marginTop = 4;
    public static final int GridLayout_Layout_android_layout_width = 0;
    public static final int GridLayout_Layout_layout_column = 10;
    public static final int GridLayout_Layout_layout_columnSpan = 11;
    public static final int GridLayout_Layout_layout_columnWeight = 12;
    public static final int GridLayout_Layout_layout_gravity = 13;
    public static final int GridLayout_Layout_layout_row = 7;
    public static final int GridLayout_Layout_layout_rowSpan = 8;
    public static final int GridLayout_Layout_layout_rowWeight = 9;
    public static final int GridLayout_alignmentMode = 4;
    public static final int GridLayout_columnCount = 2;
    public static final int GridLayout_columnOrderPreserved = 6;
    public static final int GridLayout_orientation = 0;
    public static final int GridLayout_rowCount = 1;
    public static final int GridLayout_rowOrderPreserved = 5;
    public static final int GridLayout_useDefaultMargins = 3;
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v7.gridlayout.R
 * JD-Core Version:    0.6.2
 */