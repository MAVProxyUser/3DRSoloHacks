package android.support.v4.app;

import android.app.Activity;
import android.graphics.drawable.Drawable;

abstract interface ActionBarDrawerToggle$ActionBarDrawerToggleImpl
{
  public abstract Drawable getThemeUpIndicator(Activity paramActivity);

  public abstract Object setActionBarDescription(Object paramObject, Activity paramActivity, int paramInt);

  public abstract Object setActionBarUpIndicator(Object paramObject, Activity paramActivity, Drawable paramDrawable, int paramInt);
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ActionBarDrawerToggle.ActionBarDrawerToggleImpl
 * JD-Core Version:    0.6.2
 */