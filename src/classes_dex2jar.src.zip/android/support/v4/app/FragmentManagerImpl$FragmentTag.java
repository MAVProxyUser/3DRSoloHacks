package android.support.v4.app;

class FragmentManagerImpl$FragmentTag
{
  public static final int[] Fragment = { 16842755, 16842960, 16842961 };
  public static final int Fragment_id = 1;
  public static final int Fragment_name = 0;
  public static final int Fragment_tag = 2;
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentManagerImpl.FragmentTag
 * JD-Core Version:    0.6.2
 */