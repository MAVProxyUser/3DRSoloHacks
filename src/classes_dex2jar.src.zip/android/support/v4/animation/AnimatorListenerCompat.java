package android.support.v4.animation;

public abstract interface AnimatorListenerCompat
{
  public abstract void onAnimationCancel(ValueAnimatorCompat paramValueAnimatorCompat);

  public abstract void onAnimationEnd(ValueAnimatorCompat paramValueAnimatorCompat);

  public abstract void onAnimationRepeat(ValueAnimatorCompat paramValueAnimatorCompat);

  public abstract void onAnimationStart(ValueAnimatorCompat paramValueAnimatorCompat);
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.animation.AnimatorListenerCompat
 * JD-Core Version:    0.6.2
 */