package android.support.v4.animation;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;

class HoneycombMr1AnimatorCompatProvider$HoneycombValueAnimatorCompat$1
  implements ValueAnimator.AnimatorUpdateListener
{
  HoneycombMr1AnimatorCompatProvider$HoneycombValueAnimatorCompat$1(HoneycombMr1AnimatorCompatProvider.HoneycombValueAnimatorCompat paramHoneycombValueAnimatorCompat, AnimatorUpdateListenerCompat paramAnimatorUpdateListenerCompat)
  {
  }

  public void onAnimationUpdate(ValueAnimator paramValueAnimator)
  {
    this.val$animatorUpdateListener.onAnimationUpdate(this.this$0);
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.animation.HoneycombMr1AnimatorCompatProvider.HoneycombValueAnimatorCompat.1
 * JD-Core Version:    0.6.2
 */