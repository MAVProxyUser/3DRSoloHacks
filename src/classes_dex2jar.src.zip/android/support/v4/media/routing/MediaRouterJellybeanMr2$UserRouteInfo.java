package android.support.v4.media.routing;

import android.media.MediaRouter.UserRouteInfo;

public final class MediaRouterJellybeanMr2$UserRouteInfo
{
  public static void setDescription(Object paramObject, CharSequence paramCharSequence)
  {
    ((MediaRouter.UserRouteInfo)paramObject).setDescription(paramCharSequence);
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.routing.MediaRouterJellybeanMr2.UserRouteInfo
 * JD-Core Version:    0.6.2
 */