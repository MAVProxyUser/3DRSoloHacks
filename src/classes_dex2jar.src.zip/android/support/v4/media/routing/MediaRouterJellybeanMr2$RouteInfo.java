package android.support.v4.media.routing;

import android.media.MediaRouter.RouteInfo;

public final class MediaRouterJellybeanMr2$RouteInfo
{
  public static CharSequence getDescription(Object paramObject)
  {
    return ((MediaRouter.RouteInfo)paramObject).getDescription();
  }

  public static boolean isConnecting(Object paramObject)
  {
    return ((MediaRouter.RouteInfo)paramObject).isConnecting();
  }
}

/* Location:           /Users/kfinisterre/Desktop/Solo/3DRSoloHacks/unpacked_apk/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.routing.MediaRouterJellybeanMr2.RouteInfo
 * JD-Core Version:    0.6.2
 */